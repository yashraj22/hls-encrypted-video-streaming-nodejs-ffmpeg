# HLS Video Streaming using Node.js FFMPEG

This application allows users to upload videos, convert them to HLS format, generate thumbnails, and display them on a timeline.

File Structure

- public/: Contains static files (HTML, CSS, JavaScript).
- public/videos: saving converted videos with ffmpeg
- uploads/: Temporary directory for uploaded videos.
- data.json: Stores the timeline data.

Dependencies

- express: Web framework for Node.js.
- multer: Middleware for handling multipart/form-data, used for file uploads.
- fluent-ffmpeg: A fluent API to ffmpeg, a powerful media processing tool.
- ffmpeg-static: Static ffmpeg binaries for macOS, Linux, Windows.
- ffprobe-static: Static binaries for ffprobe.
- fs-extra: Module for filesystem operations.
- path: Node.js module for handling and transforming file paths.

## Installation

Follow these steps to install and run the application:

```bash
git clone https://github.com/sushantrahate/kabu-timeline.git
cd kabu-timeline
npm Install
npm run start
```

The application should now be running on [http://localhost:3000](http://localhost:3000).

Here is the corrected and polished version:

## Usage

1. **Upload a Video:**

   - Navigate to [http://localhost:3000/upload.html](http://localhost:3000/upload.html) to upload a video.
   - The video will be uploaded to the `temp-uploads` directory using Multer, then converted and segmented into the `public/videos` directory. The metadata will be saved in `data.json`.

2. **View the Timeline:**

   - Navigate to [http://localhost:3000](http://localhost:3000).
   - The timeline will be rendered using an HLS player.
